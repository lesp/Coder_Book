var reltext = [];
reltext[1] = "Correct!!! Hyper Text Markup Language." 
reltext[2] = "Cascading Stylesheets."
reltext[3] = "Javascript. " 
reltext[4] = "NODE.JS."
reltext[5] = "Correct!!! Scratch is a visual programming tool created by MIT"
reltext[6] = "Sniff?? I don't think that is the right answer"
reltext[7] = "Itch?? I don't think that is the right answer"
reltext[8] = "Sneeze?? Would you like a hankerchief?"
reltext[9] = "Correct!!! Python is a textually based language"
reltext[10] = "Cobra, I don't think that is correct"
reltext[11] = "Viper? Aren't they the spaceships in Battlestar Galactica?"
reltext[12] = "Rattlesnake, well that isn't right is it."

function getAnswer(ans, rel) {
document.getElementById("answer").innerHTML = reltext[rel];
if (ans == "1a") {alert ("That is the right answer!")}
else if (ans == "2a") {alert ("That is the right answer!")}
else if (ans == "3a") {alert ("That is the right answer!")}
else {alert ("No - try again")}
}
